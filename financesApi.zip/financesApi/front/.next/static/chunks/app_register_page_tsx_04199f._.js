(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_register_page_tsx_04199f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_register_page_tsx_04199f._.js",
  "chunks": [
    "static/chunks/node_modules_282892._.js",
    "static/chunks/app_register_page_tsx_6ffb10._.js"
  ],
  "source": "dynamic"
});
