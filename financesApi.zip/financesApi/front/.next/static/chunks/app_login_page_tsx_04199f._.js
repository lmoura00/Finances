(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_login_page_tsx_04199f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_login_page_tsx_04199f._.js",
  "chunks": [
    "static/chunks/node_modules_b56c90._.js",
    "static/chunks/app_login_page_tsx_0f3133._.js"
  ],
  "source": "dynamic"
});
