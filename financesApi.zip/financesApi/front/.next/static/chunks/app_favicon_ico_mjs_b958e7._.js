(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_favicon_ico_mjs_b958e7._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_favicon_ico_mjs_b958e7._.js",
  "chunks": [
    "static/chunks/_16b068._.js"
  ],
  "source": "dynamic"
});
