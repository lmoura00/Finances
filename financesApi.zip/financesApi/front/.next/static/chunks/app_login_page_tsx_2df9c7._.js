(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_login_page_tsx_2df9c7._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_login_page_tsx_2df9c7._.js",
  "chunks": [
    "static/chunks/node_modules__pnpm_43eef9._.js",
    "static/chunks/app_login_page_tsx_0f3133._.js"
  ],
  "source": "dynamic"
});
