"use client";

import { useState } from 'react';
import axios from 'axios';

export default function RegisterPage() {
    const [name, setName] = useState('');
    const [cpf, setCpf] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');
    
    const handleRegister = async () => {
        if (!name || !cpf || !email || !phone || !password) {
            setMessage('Todos os campos são obrigatórios.');
            return;
        }

        try {
            const response = await axios.post(
                `${process.env.NEXT_PUBLIC_API_URL}/user`,
                {
                    name,
                    cpf,
                    email,
                    phone,
                    password,
                }
            );
            setMessage('Usuário criado com sucesso!');
            console.log('Resposta da API:', response.data);
        } catch (error) {
            console.error('Erro na API:', error);
            setMessage(error.response?.data?.message || 'Ocorreu um erro durante o registro.');
        }
    };

    return (
        <div style={{ textAlign: 'center', marginTop: '50px' }}>
            <h1>Registrar</h1>
            <input
                type="text"
                placeholder="Nome"
                value={name}
                onChange={(e) => setName(e.target.value)}
                style={{ margin: '10px', padding: '10px', color: '#000' }}
            />
            <input
                type="text"
                placeholder="CPF"
                value={cpf}
                onChange={(e) => setCpf(e.target.value)}
                style={{ margin: '10px', padding: '10px', color: '#000' }}
            />
            <input
                type="email"
                placeholder="E-mail"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                style={{ margin: '10px', padding: '10px', color: '#000' }}
            />
            <input
                type="text"
                placeholder="Telefone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                style={{ margin: '10px', padding: '10px', color: '#000' }}
            />
            <input
                type="password"
                placeholder="Senha"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                style={{ margin: '10px', padding: '10px', color: '#000' }}
            />
            <button onClick={handleRegister} style={{ margin: '10px', padding: '10px' }}>
                Registrar
            </button>
            {message && <p>{message}</p>}
        </div>
    );
}