"use client";

import { useState } from 'react';
import axios from 'axios';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');
    const router = useRouter();

    const handleLogin = async () => {
        try {
            const response = await axios.post(
                `${process.env.NEXT_PUBLIC_API_URL}/session`,
                { email, password }
            );
            console.log(email,password)
            setMessage('Login successful!');
            console.log(response.data);
        } catch (error) {
            setMessage('Login failed. Please check your credentials.');
            console.error(error);
        }
    };

    const handleGoToRegister = () => {
        router.push('/register');
    };

    return (
        <div style={{ textAlign: 'center', marginTop: '50px' }}>
            <h1>Login</h1>
            <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                style={{ margin: '10px', padding: '10px' }}
            />
            <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                style={{ margin: '10px', padding: '10px' }}
            />
            <button onClick={handleLogin} style={{ margin: '10px', padding: '10px' }}>
                Login
            </button>
            <button onClick={handleGoToRegister} style={{ margin: '10px', padding: '10px' }}>
                Register
            </button>
            {message && <p>{message}</p>}
        </div>
    );
}
